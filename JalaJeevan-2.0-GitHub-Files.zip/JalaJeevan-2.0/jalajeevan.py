#!/usr/bin/env python3
"""Offline demonstration for JalaJeevan 2.0 water monitoring.

This program analyses CSV readings. It is not pump-control firmware and
must not be used as a safety-critical controller.
"""
import argparse
import csv
from collections import defaultdict
from pathlib import Path

REQUIRED_COLUMNS = {
    "timestamp", "zone", "tank_level_pct", "flow_lpm",
    "pump_on", "energy_kwh", "delivered_litres",
}


def truthy(value):
    return str(value).strip().lower() in {"true", "1", "yes", "on"}


def analyse_rows(rows, low_tank_pct=20.0, high_tank_pct=95.0, min_flow_lpm=2.0):
    """Return alerts and zone totals for parsed row dictionaries."""
    alerts = []
    zones = defaultdict(lambda: {"delivered_litres": 0.0, "energy_kwh": 0.0, "readings": 0})

    for line_number, row in enumerate(rows, start=2):
        try:
            tank = float(row["tank_level_pct"])
            flow = float(row["flow_lpm"])
            energy = float(row["energy_kwh"])
            delivered = float(row["delivered_litres"])
        except (ValueError, TypeError, KeyError) as exc:
            alerts.append(f"Row {line_number}: invalid or missing numeric value ({exc}).")
            continue

        zone = str(row.get("zone", "")).strip() or "Unknown"
        pump_on = truthy(row.get("pump_on", "false"))

        if not 0 <= tank <= 100:
            alerts.append(f"Row {line_number} ({zone}): tank level outside 0-100%.")
        elif tank <= low_tank_pct:
            alerts.append(f"Row {line_number} ({zone}): low tank level ({tank:.1f}%).")
        elif tank >= high_tank_pct:
            alerts.append(f"Row {line_number} ({zone}): tank nearly full ({tank:.1f}%).")

        if pump_on and flow < min_flow_lpm:
            alerts.append(
                f"Row {line_number} ({zone}): pump is ON but flow is low "
                f"({flow:.1f} L/min); inspect the system."
            )

        if energy < 0 or delivered < 0:
            alerts.append(f"Row {line_number} ({zone}): energy and delivered volume must be non-negative.")
            continue

        zones[zone]["delivered_litres"] += delivered
        zones[zone]["energy_kwh"] += energy
        zones[zone]["readings"] += 1

    return alerts, dict(zones)


def load_csv(path):
    with open(path, newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames or not REQUIRED_COLUMNS.issubset(set(reader.fieldnames)):
            missing = sorted(REQUIRED_COLUMNS - set(reader.fieldnames or []))
            raise ValueError("CSV is missing required columns: " + ", ".join(missing))
        return list(reader)


def main():
    parser = argparse.ArgumentParser(description="Analyse JalaJeevan 2.0 sample water-monitoring data.")
    parser.add_argument("--input", default="data/sample_readings.csv", help="Path to input CSV")
    parser.add_argument("--low-tank", type=float, default=20.0, help="Low tank warning threshold (%)")
    parser.add_argument("--high-tank", type=float, default=95.0, help="High tank warning threshold (%)")
    parser.add_argument("--min-flow", type=float, default=2.0, help="Minimum expected flow (L/min)")
    args = parser.parse_args()

    path = Path(args.input)
    try:
        rows = load_csv(path)
    except (OSError, ValueError) as exc:
        parser.error(str(exc))

    alerts, zones = analyse_rows(rows, args.low_tank, args.high_tank, args.min_flow)
    print("JalaJeevan 2.0 — Offline Demo")
    print(f"Input: {path}")
    print("\nAlerts:")
    if alerts:
        for alert in alerts:
            print(f"- {alert}")
    else:
        print("- No alerts for the configured demonstration thresholds.")

    print("\nZone summary:")
    if not zones:
        print("- No valid zone totals.")
    else:
        print(f"{'Zone':<16} {'Delivered (L)':>15} {'Energy (kWh)':>15} {'Readings':>10}")
        for zone, totals in sorted(zones.items()):
            print(
                f"{zone:<16} {totals['delivered_litres']:>15.1f} "
                f"{totals['energy_kwh']:>15.3f} {totals['readings']:>10}"
            )
    print("\nNote: alerts are indicators for inspection, not confirmed diagnoses.")


if __name__ == "__main__":
    main()
