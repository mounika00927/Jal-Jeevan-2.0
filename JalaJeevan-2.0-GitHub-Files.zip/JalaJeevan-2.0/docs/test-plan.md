# Test Plan

Run: `python -m unittest discover -s tests -v`

| Test | Input condition | Expected result |
|---|---|---|
| T01 Low flow | Pump ON, flow below configured threshold | Low-flow inspection alert |
| T02 Low tank | Tank level at or below low threshold | Low-tank alert |
| T03 Zone totals | Multiple records for one zone | Delivered litres and energy are summed |
| T04 Negative values | Negative energy or delivered volume | Validation alert |
| T05 Missing columns | CSV omits required header | Program exits with a clear error |
| T06 Offline use | Run with local CSV and no network | Analysis completes without network access |

The included automated tests cover T01–T04. T05 is handled by CSV header validation. T06 can be checked by running the demo while disconnected from the internet.
