import unittest
from jalajeevan import analyse_rows


class TestJalaJeevan(unittest.TestCase):
    def test_low_flow_when_pump_on_triggers_alert(self):
        rows = [{
            "zone": "South", "tank_level_pct": "50", "flow_lpm": "0.5",
            "pump_on": "true", "energy_kwh": "0.1", "delivered_litres": "20",
        }]
        alerts, _ = analyse_rows(rows)
        self.assertTrue(any("pump is ON but flow is low" in alert for alert in alerts))

    def test_low_tank_triggers_alert(self):
        rows = [{
            "zone": "North", "tank_level_pct": "10", "flow_lpm": "5",
            "pump_on": "false", "energy_kwh": "0", "delivered_litres": "0",
        }]
        alerts, _ = analyse_rows(rows)
        self.assertTrue(any("low tank level" in alert for alert in alerts))

    def test_zone_totals_are_summed(self):
        rows = [
            {"zone": "North", "tank_level_pct": "50", "flow_lpm": "5", "pump_on": "false", "energy_kwh": "0.1", "delivered_litres": "100"},
            {"zone": "North", "tank_level_pct": "60", "flow_lpm": "5", "pump_on": "false", "energy_kwh": "0.2", "delivered_litres": "150"},
        ]
        _, zones = analyse_rows(rows)
        self.assertEqual(zones["North"]["delivered_litres"], 250)
        self.assertAlmostEqual(zones["North"]["energy_kwh"], 0.3)

    def test_negative_volume_is_flagged(self):
        rows = [{
            "zone": "East", "tank_level_pct": "50", "flow_lpm": "5",
            "pump_on": "false", "energy_kwh": "-1", "delivered_litres": "0",
        }]
        alerts, _ = analyse_rows(rows)
        self.assertTrue(any("must be non-negative" in alert for alert in alerts))


if __name__ == "__main__":
    unittest.main()
