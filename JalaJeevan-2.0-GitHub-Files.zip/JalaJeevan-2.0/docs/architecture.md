# Technical Design: JalaJeevan 2.0

## Purpose
Demonstrate offline analysis of water-flow, tank-level, pump-state, energy, and zone-delivery readings.

## Architecture diagram

```text
[Level Sensor]   [Flow Sensor]   [Pump Energy Meter]
      |                |                  |
      +----------------+------------------+
                       |
                [Local Controller]
              (future hardware stage)
                       |
                [Local Data Log]
                       |
                [CSV Input / Parser]
                       |
              [Rule-Based Analyzer]
               /                 \
        [Fault Alerts]      [Zone Summary]
               \                 /
                [Local Operator]
```

The current repository implements the CSV parser, rule-based analyzer, alerts, and zone summary in Python. The sensor/controller blocks are the proposed hardware architecture and are not yet implemented in this software.

## Data flow
1. Read CSV observations from a local file.
2. Validate required columns and parse numeric values.
3. Compare tank level and flow against configurable demonstration thresholds.
4. Flag possible low flow when pump state is ON.
5. Aggregate delivered litres and energy use by zone.
6. Print alerts and summaries to the terminal.

## Design choices
- **Offline-first:** all processing is local; internet is not needed.
- **Explainable rules:** alerts are simple and inspectable.
- **Modular:** CSV loading, analysis, and command-line output are separate functions.
- **Safety:** software reports possible issues; it does not switch or control a physical pump.

## Limitations and next steps
- Sample values are illustrative and not field data.
- Sensor calibration, electrical isolation, and pump safety are outside this software demo.
- Thresholds must be validated with domain experts and real measurements.
- Fairness needs contextual interpretation; volume differences alone do not prove unfair treatment.
