# JalaJeevan 2.0
**Offline-first water supply fault detection and fair-distribution monitoring prototype**

JalaJeevan 2.0 is an early software prototype for recording water-tank level, water flow, and pump electricity use. It flags possible supply faults and summarizes delivery by zone. The prototype runs locally and does not require internet access.

> **Status:** Demonstration prototype using sample/simulated readings. It has not yet been validated in a real village or connected to physical sensors. Do not use it to control a real pump without qualified engineering review and appropriate electrical protection.

## Problem
Rural water operators may have limited visibility into low flow, pump runtime/energy use, and differences in water delivered to different zones. This prototype demonstrates how simple readings could be logged and reviewed.

## Features
- Offline CSV input and local processing
- Possible low-flow alert when a pump is marked ON
- Low/high tank-level warnings
- Pump energy usage field (kWh)
- Zone-wise delivered-volume summary
- Unit tests for the main rules

## Requirements
- Python 3.10 or newer
- No third-party packages required

## Setup
1. Download or clone this repository.
2. Open a terminal in the repository folder.
3. Run the demo:

   ```bash
   python jalajeevan.py --input data/sample_readings.csv
   ```

4. Run tests:

   ```bash
   python -m unittest discover -s tests -v
   ```

## Input CSV format
Required columns:
- `timestamp`: date/time label
- `zone`: distribution zone name
- `tank_level_pct`: tank level from 0 to 100
- `flow_lpm`: flow rate in litres per minute
- `pump_on`: `true` or `false`
- `energy_kwh`: recorded energy use in kWh for the observation
- `delivered_litres`: delivered volume for the observation

The sample file is illustrative, not field-collected data. Replace it with measured data only after collecting it responsibly and with permission.

## Example output
The program prints possible alerts and a zone-wise summary. Thresholds are configurable command-line options; they are demonstration defaults, not universal engineering limits.

## Architecture
See [`docs/architecture.md`](docs/architecture.md).

## Test cases
See [`docs/test-plan.md`](docs/test-plan.md) and run the unit tests.

## Roadmap
- Validate the problem with interviews with residents/operators.
- Calibrate sensors and thresholds with qualified supervision.
- Add a safe hardware prototype using a low-voltage demonstration pump.
- Test offline data retention and compare zone delivery over time.
- Publish only measured results; do not claim savings before testing.

## UN SDGs
- SDG 6: Clean Water and Sanitation
- SDG 7: Affordable and Clean Energy
- SDG 9: Industry, Innovation and Infrastructure
- SDG 10: Reduced Inequalities

## License
Released under the MIT License. See [`LICENSE`](LICENSE).
